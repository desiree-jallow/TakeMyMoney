//
//  Paypal.swift
//  TakeMyMoney
//
//  Created by Desiree on 7/23/20.
//  Copyright © 2020 Desiree. All rights reserved.
//

import Foundation

struct Paypal {
    var userName : String
    var Password : String
}

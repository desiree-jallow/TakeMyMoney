//
//  Credit.swift
//  TakeMyMoney
//
//  Created by Desiree on 7/23/20.
//  Copyright © 2020 Desiree. All rights reserved.
//

import Foundation

struct Credit {
    var cardNumber : Int
    var validDate : Date
    var cvv : Int
    var cardHolder : String
    
}
